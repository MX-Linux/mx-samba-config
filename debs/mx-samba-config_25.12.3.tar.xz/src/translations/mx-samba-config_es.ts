<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>EditShare</name>
    <message>
        <location filename="../src/editshare.ui" line="14"/>
        <source>Dialog</source>
        <translation>Diálogo</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="20"/>
        <source>&amp;Name</source>
        <translation>&amp;Nombre</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="30"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="37"/>
        <source>&amp;Path</source>
        <translation>&amp;Ruta</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="51"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="56"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="64"/>
        <source>&amp;Comment</source>
        <translation>&amp;Comentario</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="77"/>
        <source>&amp;Guest OK</source>
        <translation>&amp;Invitado OK</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="111"/>
        <source>Access rights for valid users</source>
        <translation>Derechos de acceso para usuarios válidos</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="55"/>
        <source>Select directory to share</source>
        <translation>Seleccionar directorio para compartir</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="81"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="81"/>
        <source>Select access for at least one user before continuing.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="24"/>
        <source>&amp;Shares</source>
        <translation>&amp;Compartir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <source>Shares</source>
        <translation>Recursos compartidos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba user shares found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No se encontraron recursos compartidos de usuarios de samba&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="50"/>
        <location filename="../src/mainwindow.ui" line="157"/>
        <source>&amp;Remove</source>
        <translation>&amp;Remover</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <location filename="../src/mainwindow.ui" line="164"/>
        <source>&amp;Add</source>
        <translation>&amp;Agregar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="70"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="80"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="85"/>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="90"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <source>Permissions</source>
        <translation>Permisos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Guest OK</source>
        <translation>Invitado OK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="142"/>
        <source>&amp;Users</source>
        <translation>&amp;Usuarios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba users found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No se encontraron usuarios de samba&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="171"/>
        <source>&amp;Password</source>
        <translation>&amp;Contraseña</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <source>Users</source>
        <translation>Usuarios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <location filename="../src/mainwindow.cpp" line="320"/>
        <location filename="../src/mainwindow.cpp" line="361"/>
        <source>E&amp;nable Automatic Samba Startup</source>
        <translation>&amp;Habilitar el inicio automático de Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <location filename="../src/mainwindow.cpp" line="316"/>
        <location filename="../src/mainwindow.cpp" line="371"/>
        <source>Star&amp;t Samba</source>
        <translation>&amp;Iniciar Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="254"/>
        <source>Samba autostart service is disabled</source>
        <translation>El servicio de Autoinicio de Samba está deshabilitado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="285"/>
        <location filename="../src/mainwindow.cpp" line="317"/>
        <source>Samba is running</source>
        <translation>Samba se está ejecutando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="324"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="327"/>
        <source>A&amp;bout...</source>
        <translation>A&amp;cerca de... </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="333"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="365"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="368"/>
        <source>&amp;Help</source>
        <translation>A&amp;yuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="374"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="409"/>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="412"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <location filename="../src/mainwindow.cpp" line="109"/>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <location filename="../src/mainwindow.cpp" line="300"/>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <location filename="../src/mainwindow.cpp" line="410"/>
        <location filename="../src/mainwindow.cpp" line="442"/>
        <location filename="../src/mainwindow.cpp" line="446"/>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <location filename="../src/mainwindow.cpp" line="497"/>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <location filename="../src/mainwindow.cpp" line="510"/>
        <location filename="../src/mainwindow.cpp" line="531"/>
        <location filename="../src/mainwindow.cpp" line="548"/>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="582"/>
        <location filename="../src/mainwindow.cpp" line="597"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <source>Error, could not add share. Empty share name</source>
        <translation>Error, no se pudo agregar el recurso compartido. Nombre compartido vacío</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="101"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="109"/>
        <source>Path: %1 does not exist.</source>
        <translation>Ruta: %1 no existe.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <source>Please set access for at least one user.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <source>Could not add share. Error message:

%1</source>
        <translation>No se pudo agregar el recurso compartido. Mensaje de error:

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>Error listing users</source>
        <translation>Error enlistando usuarios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="201"/>
        <source>&amp;Deny</source>
        <translation>&amp;Negar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="202"/>
        <source>&amp;Read Only</source>
        <translation>&amp;Solo lectura</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <source>&amp;Full Access</source>
        <translation>Acceso &amp;completo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <source>Error listing shares</source>
        <translation>Error al enlistar las acciones</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="301"/>
        <source>Your user doesn&apos;t belong to &apos;sambashare&apos; group  if you just installed the app you might need to restart the system first.</source>
        <translation>Su usuario no pertenece al grupo &apos;sambashare&apos; si acaba de instalar la aplicación es posible que primero deba reiniciar el sistema.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <source>Samba is not installed</source>
        <translation>Samba no está instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="316"/>
        <source>Sto&amp;p Samba</source>
        <translation>&amp;Detener Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="317"/>
        <source>Samba is not running</source>
        <translation>Samba no se está ejecutando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="318"/>
        <source>Samba autostart is enabled</source>
        <translation>El servicio de autoinicio de Samba está habilitado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="318"/>
        <source>Samba autostart is disabled</source>
        <translation>El servicio de autoinicio de Samba está deshabilitado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="319"/>
        <source>&amp;Disable Automatic Samba Startup</source>
        <translation>&amp;Deshabilitar el inicio automático de Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>MX Samba Config</source>
        <translation>MX Configuración de Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="387"/>
        <source>Version: </source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="389"/>
        <source>Program for configuring Samba shares and users.</source>
        <translation>Programa para configurar usuarios y recursos compartidos de Samba.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="391"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="392"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="399"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="410"/>
        <source>Cannot delete user: </source>
        <translation>No se puede eliminar el usuario:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="419"/>
        <source>Enter the username and password:</source>
        <translation>Ingrese el nombre de usuario y la contraseña:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="426"/>
        <source>Username:</source>
        <translation>Nombre de usuario:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="427"/>
        <location filename="../src/mainwindow.cpp" line="483"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="428"/>
        <location filename="../src/mainwindow.cpp" line="484"/>
        <source>Confirm password:</source>
        <translation>Confirmar contraseña:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="442"/>
        <source>Empty username, please enter a name.</source>
        <translation>Nombre de usuario vacío, ingrese un nombre.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="447"/>
        <source>Matching linux user not found on system, make sure you enter a valid username.</source>
        <translation>No se encuentra el usuario de linux coincidente en el sistema, asegúrese de ingresar un nombre de usuario válido.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>Passwords don&apos;t match, please enter again.</source>
        <translation>Las contraseñas no coinciden. Vuelva a ingresarlas.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <source>Could not add user.</source>
        <translation>No se pudo agregar usuario.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <location filename="../src/mainwindow.cpp" line="520"/>
        <location filename="../src/mainwindow.cpp" line="526"/>
        <location filename="../src/mainwindow.cpp" line="543"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <source>No user selected.</source>
        <translation>No se seleccionó ningún usuario.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="477"/>
        <source>Change the password for &apos;%1&apos;</source>
        <translation>Cambiar la contraseña de &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="497"/>
        <source>Password fields cannot be empty.</source>
        <translation>Los campos de contraseña no pueden estar vacíos.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="510"/>
        <source>Could not change password.</source>
        <translation>No se pudo cambiar la contraseña.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="520"/>
        <location filename="../src/mainwindow.cpp" line="543"/>
        <source>No share selected.</source>
        <translation>No compartir seleccionado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="526"/>
        <source>Selected share is empty.</source>
        <translation>La selección a compartir está vacía.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="531"/>
        <source>Cannot delete share: </source>
        <translation>No se puede eliminar el recurso compartido:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Success</source>
        <translation>Éxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Share deleted successfully: </source>
        <translation>Compartir eliminado exitosamente:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="549"/>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Samba service is not running. Please start Samba before adding or editing shares</source>
        <translation>El servicio Samba no se está ejecutando. Inicie Samba antes de agregar o editar recursos compartidos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="582"/>
        <source>Error processing permissions: </source>
        <translation>Error al procesar permisos:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="41"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="42"/>
        <location filename="../src/about.cpp" line="51"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="43"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="63"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="76"/>
        <source>You must run this program as normal user.</source>
        <translation>Debe ejecutar este programa como un usuario normal.</translation>
    </message>
</context>
</TS>