<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="zh_TW">
<context>
    <name>EditShare</name>
    <message>
        <location filename="../src/editshare.ui" line="14"/>
        <source>Dialog</source>
        <translation>對話視窗</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="20"/>
        <source>&amp;Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="30"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="37"/>
        <source>&amp;Path</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="51"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="56"/>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="64"/>
        <source>&amp;Comment</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="77"/>
        <source>&amp;Guest OK</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="111"/>
        <source>Access rights for valid users</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="55"/>
        <source>Select directory to share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="81"/>
        <source>Warning</source>
        <translation>注意</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="81"/>
        <source>Select access for at least one user before continuing.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="24"/>
        <source>&amp;Shares</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <source>Shares</source>
        <translation>分享</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba user shares found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="50"/>
        <location filename="../src/mainwindow.ui" line="157"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <location filename="../src/mainwindow.ui" line="164"/>
        <source>&amp;Add</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="70"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="80"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="85"/>
        <source>Path</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="90"/>
        <source>Comment</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <source>Permissions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Guest OK</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="142"/>
        <source>&amp;Users</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba users found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="171"/>
        <source>&amp;Password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <source>Users</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <location filename="../src/mainwindow.cpp" line="320"/>
        <location filename="../src/mainwindow.cpp" line="361"/>
        <source>E&amp;nable Automatic Samba Startup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <location filename="../src/mainwindow.cpp" line="316"/>
        <location filename="../src/mainwindow.cpp" line="371"/>
        <source>Star&amp;t Samba</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="254"/>
        <source>Samba autostart service is disabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="285"/>
        <location filename="../src/mainwindow.cpp" line="317"/>
        <source>Samba is running</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="324"/>
        <source>About this application</source>
        <translation>關於本程式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="327"/>
        <source>A&amp;bout...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="333"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="365"/>
        <source>Display help </source>
        <translation>顯示說明</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="368"/>
        <source>&amp;Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="374"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="409"/>
        <source>Quit application</source>
        <translation>退出程式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="412"/>
        <source>&amp;Close</source>
        <translation>關閉（&amp;C）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <location filename="../src/mainwindow.cpp" line="109"/>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <location filename="../src/mainwindow.cpp" line="300"/>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <location filename="../src/mainwindow.cpp" line="410"/>
        <location filename="../src/mainwindow.cpp" line="442"/>
        <location filename="../src/mainwindow.cpp" line="446"/>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <location filename="../src/mainwindow.cpp" line="497"/>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <location filename="../src/mainwindow.cpp" line="510"/>
        <location filename="../src/mainwindow.cpp" line="531"/>
        <location filename="../src/mainwindow.cpp" line="548"/>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="582"/>
        <location filename="../src/mainwindow.cpp" line="597"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <source>Error, could not add share. Empty share name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="101"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="109"/>
        <source>Path: %1 does not exist.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <source>Please set access for at least one user.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <source>Could not add share. Error message:

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>Error listing users</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="201"/>
        <source>&amp;Deny</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="202"/>
        <source>&amp;Read Only</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <source>&amp;Full Access</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <source>Error listing shares</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="301"/>
        <source>Your user doesn&apos;t belong to &apos;sambashare&apos; group  if you just installed the app you might need to restart the system first.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <source>Samba is not installed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="316"/>
        <source>Sto&amp;p Samba</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="317"/>
        <source>Samba is not running</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="318"/>
        <source>Samba autostart is enabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="318"/>
        <source>Samba autostart is disabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="319"/>
        <source>&amp;Disable Automatic Samba Startup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>About %1</source>
        <translation>大約 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>MX Samba Config</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="387"/>
        <source>Version: </source>
        <translation>版本：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="389"/>
        <source>Program for configuring Samba shares and users.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="391"/>
        <source>Copyright (c) MX Linux</source>
        <translation>MX Linux 版權所有 (c)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="392"/>
        <source>%1 License</source>
        <translation>%1 許可</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="399"/>
        <source>%1 Help</source>
        <translation>%1 幫助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="410"/>
        <source>Cannot delete user: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="419"/>
        <source>Enter the username and password:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="426"/>
        <source>Username:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="427"/>
        <location filename="../src/mainwindow.cpp" line="483"/>
        <source>Password:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="428"/>
        <location filename="../src/mainwindow.cpp" line="484"/>
        <source>Confirm password:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="442"/>
        <source>Empty username, please enter a name.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="447"/>
        <source>Matching linux user not found on system, make sure you enter a valid username.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>Passwords don&apos;t match, please enter again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <source>Could not add user.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <location filename="../src/mainwindow.cpp" line="520"/>
        <location filename="../src/mainwindow.cpp" line="526"/>
        <location filename="../src/mainwindow.cpp" line="543"/>
        <source>Warning</source>
        <translation>注意</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <source>No user selected.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="477"/>
        <source>Change the password for &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="497"/>
        <source>Password fields cannot be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="510"/>
        <source>Could not change password.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="520"/>
        <location filename="../src/mainwindow.cpp" line="543"/>
        <source>No share selected.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="526"/>
        <source>Selected share is empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="531"/>
        <source>Cannot delete share: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Success</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Share deleted successfully: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="549"/>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Samba service is not running. Please start Samba before adding or editing shares</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="582"/>
        <source>Error processing permissions: </source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="41"/>
        <source>License</source>
        <translation>授權條款</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="42"/>
        <location filename="../src/about.cpp" line="51"/>
        <source>Changelog</source>
        <translation>變更紀錄</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="43"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="63"/>
        <source>&amp;Close</source>
        <translation>關閉（&amp;C）</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="76"/>
        <source>You must run this program as normal user.</source>
        <translation>本程式必須以一般使用者的身份來執行。</translation>
    </message>
</context>
</TS>