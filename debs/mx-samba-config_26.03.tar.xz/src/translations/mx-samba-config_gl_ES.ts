<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="gl_ES">
<context>
    <name>EditShare</name>
    <message>
        <location filename="../src/editshare.ui" line="14"/>
        <source>Dialog</source>
        <translation>Diálogo</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="20"/>
        <source>&amp;Name</source>
        <translation>&amp;Nome</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="30"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="37"/>
        <source>&amp;Path</source>
        <translation>Camiño</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="51"/>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="56"/>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="64"/>
        <source>&amp;Comment</source>
        <translation>&amp;Comentario</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="77"/>
        <source>&amp;Guest OK</source>
        <translation>Convidado OK</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="111"/>
        <source>Access rights for valid users</source>
        <translation>Dereitos de acceso para usuarios válidos</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="55"/>
        <source>Select directory to share</source>
        <translation>Selecciona o directorio para compartir.</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="81"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="81"/>
        <source>Select access for at least one user before continuing.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="24"/>
        <source>&amp;Shares</source>
        <translation>&amp;Intercambios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <source>Shares</source>
        <translation>Intercambios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba user shares found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Non se atoparon comparticións de usuarios de Samba&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="50"/>
        <location filename="../src/mainwindow.ui" line="157"/>
        <source>&amp;Remove</source>
        <translation>Elimina&amp;r</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <location filename="../src/mainwindow.ui" line="164"/>
        <source>&amp;Add</source>
        <translation>Eng&amp;adir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="70"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="80"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="85"/>
        <source>Path</source>
        <translation>Camiño</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="90"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <source>Permissions</source>
        <translation>Permisos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Guest OK</source>
        <translation>Convidado OK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="142"/>
        <source>&amp;Users</source>
        <translation>&amp;Usuarios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba users found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Non se atoparon comparticións de usuarios de Samba&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="171"/>
        <source>&amp;Password</source>
        <translation>Contrasinal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <source>Users</source>
        <translation>Usuarios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <location filename="../src/mainwindow.cpp" line="320"/>
        <location filename="../src/mainwindow.cpp" line="361"/>
        <source>E&amp;nable Automatic Samba Startup</source>
        <translation>Habilitar I&amp;nicio Automático de Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <location filename="../src/mainwindow.cpp" line="316"/>
        <location filename="../src/mainwindow.cpp" line="371"/>
        <source>Star&amp;t Samba</source>
        <translation>Iniciar Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="254"/>
        <source>Samba autostart service is disabled</source>
        <translation>O  inicio automático do servizo Samba está desactivado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="285"/>
        <location filename="../src/mainwindow.cpp" line="317"/>
        <source>Samba is running</source>
        <translation>Samba está en execución.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="324"/>
        <source>About this application</source>
        <translation>Sobre esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="327"/>
        <source>A&amp;bout...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="333"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="365"/>
        <source>Display help </source>
        <translation>Amosar axuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="368"/>
        <source>&amp;Help</source>
        <translation>&amp;Axuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="374"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="409"/>
        <source>Quit application</source>
        <translation>Saír do aplicativo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="412"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <location filename="../src/mainwindow.cpp" line="109"/>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <location filename="../src/mainwindow.cpp" line="300"/>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <location filename="../src/mainwindow.cpp" line="410"/>
        <location filename="../src/mainwindow.cpp" line="442"/>
        <location filename="../src/mainwindow.cpp" line="446"/>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <location filename="../src/mainwindow.cpp" line="497"/>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <location filename="../src/mainwindow.cpp" line="510"/>
        <location filename="../src/mainwindow.cpp" line="531"/>
        <location filename="../src/mainwindow.cpp" line="548"/>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="582"/>
        <location filename="../src/mainwindow.cpp" line="597"/>
        <location filename="../src/mainwindow.cpp" line="603"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <source>Error, could not add share. Empty share name</source>
        <translation>Erro, non se puido engadir a compartición. Nome de compartición baleiro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="101"/>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="109"/>
        <source>Path: %1 does not exist.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <source>Please set access for at least one user.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <source>Could not add share. Error message:

%1</source>
        <translation>Non se puido engadir a compartición. Mensaxe de erro:

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>Error listing users</source>
        <translation>Erro ao listar usuarios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="201"/>
        <source>&amp;Deny</source>
        <translation>&amp;Denegar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="202"/>
        <source>&amp;Read Only</source>
        <translation>Só lectu&amp;ra</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <source>&amp;Full Access</source>
        <translation>Acceso completo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <source>Error listing shares</source>
        <translation>Erro ao listar comparticións</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="301"/>
        <source>Your user doesn&apos;t belong to &apos;sambashare&apos; group  if you just installed the app you might need to restart the system first.</source>
        <translation>O teu usuario non pertence ao grupo &apos;sambashare&apos;. Se acabas de instalar a aplicación, pode que necesites reiniciar o sistema primeiro.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <source>Samba is not installed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="316"/>
        <source>Sto&amp;p Samba</source>
        <translation>&amp;Parar Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="317"/>
        <source>Samba is not running</source>
        <translation>Samba non está en execución.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="318"/>
        <source>Samba autostart is enabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="318"/>
        <source>Samba autostart is disabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="319"/>
        <source>&amp;Disable Automatic Samba Startup</source>
        <translation>&amp;Desactivar Inicio Automático de Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>About %1</source>
        <translation>Sobre %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>MX Samba Config</source>
        <translation>MX Configuración de Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="387"/>
        <source>Version: </source>
        <translation>Versión: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="389"/>
        <source>Program for configuring Samba shares and users.</source>
        <translation>Programa para configurar comparticións e usuarios de Samba.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="391"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="392"/>
        <source>%1 License</source>
        <translation>Licenza de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="399"/>
        <source>%1 Help</source>
        <translation>Axuda para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="410"/>
        <source>Cannot delete user: </source>
        <translation>Non se pode eliminar o usuario:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="419"/>
        <source>Enter the username and password:</source>
        <translation>Introduce o nome de usuario e o contrasinal:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="426"/>
        <source>Username:</source>
        <translation>Nome de usuario:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="427"/>
        <location filename="../src/mainwindow.cpp" line="483"/>
        <source>Password:</source>
        <translation>Contrasinal:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="428"/>
        <location filename="../src/mainwindow.cpp" line="484"/>
        <source>Confirm password:</source>
        <translation>Confirmar contrasinal:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="442"/>
        <source>Empty username, please enter a name.</source>
        <translation>Nome de usuario baleiro, por favor, introduce un nome.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="447"/>
        <source>Matching linux user not found on system, make sure you enter a valid username.</source>
        <translation>Non se atopou ningún usuario de Linux no sistema, asegúrate de introducir un nome de usuario válido.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>Passwords don&apos;t match, please enter again.</source>
        <translation>As contrasinais non coinciden, por favor, introduza de novo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <source>Could not add user.</source>
        <translation>Non se puido engadir o usuario.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <location filename="../src/mainwindow.cpp" line="520"/>
        <location filename="../src/mainwindow.cpp" line="526"/>
        <location filename="../src/mainwindow.cpp" line="543"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <source>No user selected.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="477"/>
        <source>Change the password for &apos;%1&apos;</source>
        <translation>Cambiar o contrasinal para &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="497"/>
        <source>Password fields cannot be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="510"/>
        <source>Could not change password.</source>
        <translation>Non se puido cambiar o contrasinal.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="520"/>
        <location filename="../src/mainwindow.cpp" line="543"/>
        <source>No share selected.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="526"/>
        <source>Selected share is empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="531"/>
        <source>Cannot delete share: </source>
        <translation>Non se pode eliminar a compartición:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Success</source>
        <translation>Con éxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Share deleted successfully: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="549"/>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Samba service is not running. Please start Samba before adding or editing shares</source>
        <translation>O servizo Samba non está en execución. Por favor, inicie o Samba antes de engadir ou editar comparticións.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="582"/>
        <source>Error processing permissions: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="603"/>
        <source>Please add a Samba user before creating a share.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="41"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="42"/>
        <location filename="../src/about.cpp" line="51"/>
        <source>Changelog</source>
        <translation>Rexistro dos cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="43"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="63"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="76"/>
        <source>You must run this program as normal user.</source>
        <translation>Dbeeb executar este programa como usuario normal.</translation>
    </message>
</context>
</TS>