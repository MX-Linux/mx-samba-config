<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="hu">
<context>
    <name>EditShare</name>
    <message>
        <location filename="../src/editshare.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialógus</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="20"/>
        <source>&amp;Name</source>
        <translation>&amp;Név</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="30"/>
        <source>Browse for a folder to share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="33"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="40"/>
        <source>&amp;Path</source>
        <translation>&amp;Útvonal</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="50"/>
        <source>Full path to the folder to share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="57"/>
        <source>Allow access without a username or password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="61"/>
        <source>Yes</source>
        <translation>Igen</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="66"/>
        <source>No</source>
        <translation>Nem</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="74"/>
        <source>&amp;Comment</source>
        <translation>&amp;Megjegyzés</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="84"/>
        <source>Name clients will see for this share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="91"/>
        <source>&amp;Guest OK</source>
        <translation>&amp;Vendég OK</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="101"/>
        <source>Optional description shown to clients</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="129"/>
        <source>Access rights for valid users</source>
        <translation>Jogosultságok érvényes felhasználóknak</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="55"/>
        <source>Select directory to share</source>
        <translation>Válassza ki a megosztandó könyvtárat</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="81"/>
        <source>Warning</source>
        <translation>Figyelmeztetés</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="81"/>
        <source>Select access for at least one user before continuing.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="24"/>
        <source>&amp;Shares</source>
        <translation>&amp;Megosztások</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <source>Shares</source>
        <translation>Megosztások</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba user shares found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nincsenek samba felhasználói megosztások&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="50"/>
        <source>Remove the selected share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="53"/>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Remove</source>
        <translation>&amp;Eltávolítás</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="60"/>
        <source>Create a new Samba share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="69"/>
        <location filename="../src/mainwindow.ui" line="179"/>
        <source>&amp;Add</source>
        <translation>&amp;Hozzáadás</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>Edit the selected share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>&amp;Edit</source>
        <translation>&amp;Szerkesztés</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="89"/>
        <source>Name</source>
        <translation>Név</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="94"/>
        <source>Path</source>
        <translation>Útvonal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="99"/>
        <source>Comment</source>
        <translation>Megjegyzés</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Permissions</source>
        <translation>Jogosultságok</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="109"/>
        <source>Guest OK</source>
        <translation>Vendég OK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="151"/>
        <source>&amp;Users</source>
        <translation>&amp;Felhasználók</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba users found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nincsenek samba felhasználók&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Remove the selected Samba user</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="176"/>
        <source>Add a Samba user (must match an existing Linux user)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="186"/>
        <source>Change the selected user&apos;s Samba password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>&amp;Password</source>
        <translation>&amp;Jelszó</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="212"/>
        <source>Users</source>
        <translation>Felhasználók</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="237"/>
        <source>Enable or disable starting Samba automatically at boot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="240"/>
        <location filename="../src/mainwindow.cpp" line="324"/>
        <location filename="../src/mainwindow.cpp" line="371"/>
        <source>E&amp;nable Automatic Samba Startup</source>
        <translation>&amp;Automatikus samba indítás engedélyezése</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="247"/>
        <source>Start or stop the Samba service</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="250"/>
        <location filename="../src/mainwindow.cpp" line="320"/>
        <location filename="../src/mainwindow.cpp" line="381"/>
        <source>Star&amp;t Samba</source>
        <translation>&amp;Samba indítása</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="278"/>
        <source>Samba autostart service is disabled</source>
        <translation>Samba automatikus indítása letiltva</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="309"/>
        <location filename="../src/mainwindow.cpp" line="321"/>
        <source>Samba is running</source>
        <translation>A samba fut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="348"/>
        <source>About this application</source>
        <translation>Az alkalmazásról</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="351"/>
        <source>A&amp;bout...</source>
        <translation>&amp;Névjegy...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="357"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="389"/>
        <source>Display help </source>
        <translation>Súgó megjelenítése</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>&amp;Help</source>
        <translation>&amp;Súgó</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="398"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Quit application</source>
        <translation>Kilépés az alkalmazásból</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>&amp;Close</source>
        <translation>&amp;Bezárás</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="442"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <location filename="../src/mainwindow.cpp" line="109"/>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <location filename="../src/mainwindow.cpp" line="304"/>
        <location filename="../src/mainwindow.cpp" line="315"/>
        <location filename="../src/mainwindow.cpp" line="420"/>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <location filename="../src/mainwindow.cpp" line="456"/>
        <location filename="../src/mainwindow.cpp" line="462"/>
        <location filename="../src/mainwindow.cpp" line="469"/>
        <location filename="../src/mainwindow.cpp" line="507"/>
        <location filename="../src/mainwindow.cpp" line="512"/>
        <location filename="../src/mainwindow.cpp" line="520"/>
        <location filename="../src/mainwindow.cpp" line="541"/>
        <location filename="../src/mainwindow.cpp" line="558"/>
        <location filename="../src/mainwindow.cpp" line="577"/>
        <location filename="../src/mainwindow.cpp" line="592"/>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <location filename="../src/mainwindow.cpp" line="613"/>
        <source>Error</source>
        <translation>Hiba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <source>Error, could not add share. Empty share name</source>
        <translation>Hiba, a megosztás hozzáadása nem sikerült. Nincs neve</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="101"/>
        <source>Yes</source>
        <translation>Igen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="109"/>
        <source>Path: %1 does not exist.</source>
        <translation>Az útvonal: %1 nem létezik.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <source>Please set access for at least one user.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <source>Could not add share. Error message:

%1</source>
        <translation>A megosztás hozzáadása nem sikerült. Hibaüzenet:

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>Error listing users</source>
        <translation>Hiba a felhasználók listázásakor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="201"/>
        <source>&amp;Deny</source>
        <translation>&amp;Tiltás</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="202"/>
        <source>&amp;Read Only</source>
        <translation>&amp;Csak olvasható</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <source>&amp;Full Access</source>
        <translation>&amp;Teljes elérés</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <source>Error listing shares</source>
        <translation>Hiba a megosztások listázásakor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="305"/>
        <source>Your user doesn&apos;t belong to &apos;sambashare&apos; group  if you just installed the app you might need to restart the system first.</source>
        <translation>A felhasználója nem tagja a &apos;sambashare&apos; csoportnak. Ha csak most telepítette az alkalmazást, a gép újraindítása lehet szükséges.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="315"/>
        <source>Samba is not installed</source>
        <translation>A Samba nincs telepítve.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="320"/>
        <source>Sto&amp;p Samba</source>
        <translation>&amp;Samba leállítása</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="321"/>
        <source>Samba is not running</source>
        <translation>A samba nem fut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="322"/>
        <source>Samba autostart is enabled</source>
        <translation>A Samba automatikus indítása engedélyezve van.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="322"/>
        <source>Samba autostart is disabled</source>
        <translation>A Samba automatikus indítása letiltva.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="323"/>
        <source>&amp;Disable Automatic Samba Startup</source>
        <translation>Samba automatikus indításának &amp;letiltása</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>About %1</source>
        <translation>%1 névjegye</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>MX Samba Config</source>
        <translation>MX Samba Beállítások</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>Version: </source>
        <translation>Verzió:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="400"/>
        <source>Program for configuring Samba shares and users.</source>
        <translation>Program a Samba megosztások és felhasználók beállításához</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>%1 License</source>
        <translation>%1 licenc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="409"/>
        <source>%1 Help</source>
        <translation>%1 súgó</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="420"/>
        <source>Cannot delete user: </source>
        <translation>Felhasználó nem törölhető:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="429"/>
        <source>Enter the username and password:</source>
        <translation>Adja meg a felhasználónevet és a jelszót:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>Username:</source>
        <translation>Felhasználónév:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="437"/>
        <location filename="../src/mainwindow.cpp" line="493"/>
        <source>Password:</source>
        <translation>Jelszó:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="438"/>
        <location filename="../src/mainwindow.cpp" line="494"/>
        <source>Confirm password:</source>
        <translation>Jelszó megerősítése:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <source>Empty username, please enter a name.</source>
        <translation>Felhasználónév üres. Adjon meg egy nevet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="457"/>
        <source>Matching linux user not found on system, make sure you enter a valid username.</source>
        <translation>Nincs ilyen Linux felhasználó a rendszeren. Adjon meg egy érvényes felhasználónevet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="462"/>
        <location filename="../src/mainwindow.cpp" line="512"/>
        <source>Passwords don&apos;t match, please enter again.</source>
        <translation>A jelszavak nem egyeznek. Próbálja meg újra.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="469"/>
        <source>Could not add user.</source>
        <translation>Felhasználó hozzáadása nem sikerült.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="480"/>
        <location filename="../src/mainwindow.cpp" line="530"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <location filename="../src/mainwindow.cpp" line="553"/>
        <source>Warning</source>
        <translation>Figyelmeztetés</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="480"/>
        <source>No user selected.</source>
        <translation>Nincs kiválasztva felhasználó.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="487"/>
        <source>Change the password for &apos;%1&apos;</source>
        <translation>&apos;%1&apos; jelszavának megváltoztatása</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="507"/>
        <source>Password fields cannot be empty.</source>
        <translation>A jelszó mezők nem lehetnek üresek.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="520"/>
        <source>Could not change password.</source>
        <translation>Jelszó megváltoztatása nem sikerült.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="530"/>
        <location filename="../src/mainwindow.cpp" line="553"/>
        <source>No share selected.</source>
        <translation>Nincs kiválasztva megosztás.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Selected share is empty.</source>
        <translation>A kiválasztott megosztás üres.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="541"/>
        <source>Cannot delete share: </source>
        <translation>A megosztás nem törölhető:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="546"/>
        <source>Success</source>
        <translation>Sikeres</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="546"/>
        <source>Share deleted successfully: </source>
        <translation>A megosztás sikeresen törölve:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="559"/>
        <location filename="../src/mainwindow.cpp" line="608"/>
        <source>Samba service is not running. Please start Samba before adding or editing shares</source>
        <translation>A Samba szolgáltatás nem fut. Indítsa el s Sambát megosztások létrehozása vagy szerkesztése előtt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="577"/>
        <location filename="../src/mainwindow.cpp" line="592"/>
        <source>Error processing permissions: </source>
        <translation>Hiba a jogosultságok feldolgozása során:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="613"/>
        <source>Please add a Samba user before creating a share.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licenc</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Változások listája</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="47"/>
        <location filename="../src/about.cpp" line="117"/>
        <source>&amp;Close</source>
        <translation>&amp;Bezárás</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="76"/>
        <source>You must run this program as normal user.</source>
        <translation>Egyszerű felhasználóként kell futtatnia ezt a programot.</translation>
    </message>
</context>
</TS>