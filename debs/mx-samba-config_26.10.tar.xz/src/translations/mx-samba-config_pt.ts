<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt">
<context>
    <name>EditShare</name>
    <message>
        <location filename="../src/editshare.ui" line="14"/>
        <source>Dialog</source>
        <translation>Caixa de diálogo</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="20"/>
        <source>&amp;Name</source>
        <translation>&amp;Nome</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="30"/>
        <source>Browse for a folder to share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="33"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="40"/>
        <source>&amp;Path</source>
        <translation>Ca&amp;minho</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="50"/>
        <source>Full path to the folder to share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="57"/>
        <source>Allow access without a username or password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="61"/>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="66"/>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="74"/>
        <source>&amp;Comment</source>
        <translation>&amp;Comentário</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="84"/>
        <source>Name clients will see for this share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="91"/>
        <source>&amp;Guest OK</source>
        <translation>&amp;Convidado OK</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="101"/>
        <source>Optional description shown to clients</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="111"/>
        <source>Changes apply to new connections. Clients that are already connected keep their current access until they reconnect. Restart Samba to apply the change to everyone immediately.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="142"/>
        <source>Access rights for valid users</source>
        <translation>Permissões de acesso para os utilizadores válidos</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="78"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="80"/>
        <source>Remove this access rule</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="133"/>
        <source>Select directory to share</source>
        <translation>Selecione o directório a partilhar</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="142"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="142"/>
        <source>Select access for at least one user before continuing.</source>
        <translation>Escolha o acesso a pelo menos um utilizador antes de continuar.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="24"/>
        <source>&amp;Shares</source>
        <translation>&amp;Partilhas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <source>Shares</source>
        <translation>Partilhas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba user shares found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Não foram encontradas partilhas de utilizador no servidor Samba&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="50"/>
        <source>Remove the selected share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="53"/>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Remove</source>
        <translation>&amp;Remover</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="60"/>
        <source>Create a new Samba share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="69"/>
        <location filename="../src/mainwindow.ui" line="179"/>
        <source>&amp;Add</source>
        <translation>&amp;Adicionar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>Edit the selected share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="89"/>
        <source>Name</source>
        <translation>Opção para informação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="94"/>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="99"/>
        <source>Comment</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Permissions</source>
        <translation>Permissões </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="109"/>
        <source>Guest OK</source>
        <translation>Convidado OK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="151"/>
        <source>&amp;Users</source>
        <translation>&amp;Utilizadores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba users found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Não foram encontrados utilizadores no servidor Samba&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Remove the selected Samba user</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="176"/>
        <source>Add a Samba user (must match an existing Linux user)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="186"/>
        <source>Change the selected user&apos;s Samba password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>&amp;Password</source>
        <translation>&amp;Senha </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="225"/>
        <source>Users</source>
        <translation>Utilizadores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="250"/>
        <source>Enable or disable starting Samba automatically at boot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="253"/>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <location filename="../src/mainwindow.cpp" line="405"/>
        <source>E&amp;nable Automatic Samba Startup</source>
        <translation>Ativar o arra_nque automático do servidor Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="260"/>
        <source>Start or stop the Samba service</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <location filename="../src/mainwindow.cpp" line="354"/>
        <location filename="../src/mainwindow.cpp" line="415"/>
        <source>Star&amp;t Samba</source>
        <translation>&amp;Iniciar o servidor Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="291"/>
        <source>Samba autostart service is disabled</source>
        <translation>O serviço de arranque automático do servidor Samba está desativado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <location filename="../src/mainwindow.cpp" line="355"/>
        <source>Samba is running</source>
        <translation>O servidor Samba está em execução</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="361"/>
        <source>About this application</source>
        <translation>Sobre esta aplicação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="364"/>
        <source>A&amp;bout...</source>
        <translation>&amp;Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="370"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Display help </source>
        <translation>Mostrar ajuda </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="405"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Quit application</source>
        <translation>Sair da aplicação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="449"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="455"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="118"/>
        <location filename="../src/mainwindow.cpp" line="123"/>
        <location filename="../src/mainwindow.cpp" line="130"/>
        <location filename="../src/mainwindow.cpp" line="144"/>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <location filename="../src/mainwindow.cpp" line="338"/>
        <location filename="../src/mainwindow.cpp" line="349"/>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <location filename="../src/mainwindow.cpp" line="534"/>
        <location filename="../src/mainwindow.cpp" line="568"/>
        <location filename="../src/mainwindow.cpp" line="572"/>
        <location filename="../src/mainwindow.cpp" line="578"/>
        <location filename="../src/mainwindow.cpp" line="585"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <location filename="../src/mainwindow.cpp" line="628"/>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="118"/>
        <source>Error, could not add share. Empty share name</source>
        <translation>Erro, não foi possível adicionar partilha. Nome da partilha vazia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="115"/>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="123"/>
        <source>Path: %1 does not exist.</source>
        <translation>Caminho: %1 não existe.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="130"/>
        <source>Please set access for at least one user.</source>
        <translation>Configure o acesso a pelo menos um utilizador.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="145"/>
        <source>Could not add share. Error message:

%1</source>
        <translation>Não foi possível adicionar a partilha. Erro:

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <source>Error listing users</source>
        <translation>Erro ao listar os utilizadores</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="60"/>
        <source>&amp;Deny</source>
        <translation>&amp;Negar</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="61"/>
        <source>&amp;Read Only</source>
        <translation>Só &amp;Leitura</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="62"/>
        <source>&amp;Full Access</source>
        <translation>Acesso &amp;Total</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <source>Error listing shares</source>
        <translation>Erro ao listar as partilhas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="312"/>
        <source>Each Samba user can also open their own home folder, read-only, as \\%1\&lt;user name&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="313"/>
        <source>Each Samba user can also open their own home folder, with write access, as \\%1\&lt;user name&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="315"/>
        <source>This is set by the [homes] section in /etc/samba/smb.conf.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="339"/>
        <source>Your user doesn&apos;t belong to &apos;sambashare&apos; group  if you just installed the app you might need to restart the system first.</source>
        <translation>O seu utilizador não pertence ao grupo &apos;sambashare&apos; se tiver acabado de instalar a aplicação, poderá ter de reiniciar o sistema primeiro.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="349"/>
        <source>Samba is not installed</source>
        <translation>O servidor Samba não está instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="354"/>
        <source>Sto&amp;p Samba</source>
        <translation>&amp;Parar o servidor Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="355"/>
        <source>Samba is not running</source>
        <translation>O servidor Samba não está em execução</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="356"/>
        <source>Samba autostart is enabled</source>
        <translation>O início automático do servidor Samba está activado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="356"/>
        <source>Samba autostart is disabled</source>
        <translation>O início automático do servidor Samba está desactivado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="357"/>
        <source>&amp;Disable Automatic Samba Startup</source>
        <translation>&amp;Desativar o arranque automático do servidor Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>MX Samba Config</source>
        <translation>MX Configurar o Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="432"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="434"/>
        <source>Program for configuring Samba shares and users.</source>
        <translation>Programa para configurar partilhas pelo Samba e utilizadores do programa.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>Copyright (c) MX Linux</source>
        <translation> Direitos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="437"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="443"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="495"/>
        <source>%1 is listed on these shares:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="497"/>
        <source>Remove %1&apos;s access from: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="500"/>
        <source>Remove these shares, which no one else can access: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>Remove User</source>
        <translation>Remover Utilizador </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="503"/>
        <source>Remove from Shares</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="504"/>
        <source>Keep Entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <source>Cannot delete user: </source>
        <translation>Não é possível eliminar o utilizador:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <source>%1 was removed, but these shares could not be updated: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="545"/>
        <source>Enter the username and password:</source>
        <translation>Introduzir o nome de utilizador e a senha:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="552"/>
        <source>Username:</source>
        <translation>Utilizador:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="553"/>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="554"/>
        <location filename="../src/mainwindow.cpp" line="610"/>
        <source>Confirm password:</source>
        <translation>Confirmar a senha:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="568"/>
        <source>Empty username, please enter a name.</source>
        <translation>Utilizador não introduzido. Introduzir um nome de utilizador.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="573"/>
        <source>Matching linux user not found on system, make sure you enter a valid username.</source>
        <translation>Utilizador linux correspondente não encontrado no sistema. Certifique-se de introduzir um nome de utilizador válido.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="578"/>
        <location filename="../src/mainwindow.cpp" line="628"/>
        <source>Passwords don&apos;t match, please enter again.</source>
        <translation>As senhas não coincidem. Introduzir novamente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="585"/>
        <source>Could not add user.</source>
        <translation>Não foi possível adicionar o utilizador.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="596"/>
        <location filename="../src/mainwindow.cpp" line="646"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <location filename="../src/mainwindow.cpp" line="672"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="596"/>
        <source>No user selected.</source>
        <translation>Nenhum utilizador selecionado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="603"/>
        <source>Change the password for &apos;%1&apos;</source>
        <translation>Alterar a senha para &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <source>Password fields cannot be empty.</source>
        <translation>Os campos da palavra-passe não podem estar vazios.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>Could not change password.</source>
        <translation>Não foi possível alterar a senha.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="646"/>
        <location filename="../src/mainwindow.cpp" line="672"/>
        <source>No share selected.</source>
        <translation>Nenhuma partilha selecionada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Selected share is empty.</source>
        <translation>A partilha selecionada está vazia.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <source>Cannot delete share: </source>
        <translation>Não foi possível eliminar a partilha:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <source>Success</source>
        <translation>Sucesso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <source>Share deleted successfully: </source>
        <translation>Partilha eliminada com sucesso: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <location filename="../src/mainwindow.cpp" line="766"/>
        <source>Samba service is not running. Please start Samba before adding or editing shares</source>
        <translation>O serviço Samba não está em execução. Inicie o servidor Samba antes de adicionar ou editar as partilhas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="683"/>
        <source>Edit Share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="689"/>
        <source>Share names cannot be changed when editing an existing share.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <source>Error processing permissions: </source>
        <translation>Erro ao processar permissões: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="755"/>
        <source>Several existing rules refer to this name; edit them individually.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Please add a Samba user before creating a share.</source>
        <translation>Escolha um utilizador Samba antes de criar uma partilha,</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <source>Add Share</source>
        <translation>Adicionar Partilha</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>Could not load %1</source>
        <translation>Foi impossível carregar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Registo de alterações</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="47"/>
        <location filename="../src/about.cpp" line="117"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <source>You must run this program as normal user.</source>
        <translation>Este programa tem que ser executado como utilizador normal.</translation>
    </message>
</context>
</TS>