<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sl">
<context>
    <name>EditShare</name>
    <message>
        <location filename="../src/editshare.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="20"/>
        <source>&amp;Name</source>
        <translation>&amp;Ime</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="30"/>
        <source>Browse for a folder to share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="33"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="40"/>
        <source>&amp;Path</source>
        <translation>&amp;Pot</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="50"/>
        <source>Full path to the folder to share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="57"/>
        <source>Allow access without a username or password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="61"/>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="66"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="74"/>
        <source>&amp;Comment</source>
        <translation>%Komentar</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="84"/>
        <source>Name clients will see for this share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="91"/>
        <source>&amp;Guest OK</source>
        <translation>&amp;Gost OK</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="101"/>
        <source>Optional description shown to clients</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="111"/>
        <source>Changes apply to new connections. Clients that are already connected keep their current access until they reconnect. Restart Samba to apply the change to everyone immediately.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="142"/>
        <source>Access rights for valid users</source>
        <translation>Dostopne pravice za veljavne uporabnike</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="78"/>
        <source>Remove</source>
        <translation>Odstrani</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="80"/>
        <source>Remove this access rule</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="133"/>
        <source>Select directory to share</source>
        <translation>Izberite direktorij za skupno rabo</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="142"/>
        <source>Warning</source>
        <translation>Opozorilo</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="142"/>
        <source>Select access for at least one user before continuing.</source>
        <translation>Pred nadaljevanjem izberite dostop za vsaj enega uporabnika.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="24"/>
        <source>&amp;Shares</source>
        <translation>&amp;Skupna raba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <source>Shares</source>
        <translation>Skupna raba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba user shares found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ni najdenih uporabniških map v skupni rabi&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="50"/>
        <source>Remove the selected share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="53"/>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Remove</source>
        <translation>&amp;Odstrani</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="60"/>
        <source>Create a new Samba share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="69"/>
        <location filename="../src/mainwindow.ui" line="179"/>
        <source>&amp;Add</source>
        <translation>&amp;Dodaj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>Edit the selected share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>&amp;Edit</source>
        <translation>Ur&amp;edi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="89"/>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="94"/>
        <source>Path</source>
        <translation>Pot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="99"/>
        <source>Comment</source>
        <translation>Komentar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Permissions</source>
        <translation>Dovoljenja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="109"/>
        <source>Guest OK</source>
        <translation>Gost OK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="151"/>
        <source>&amp;Users</source>
        <translation>&amp;Uporabniki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba users found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ni najdenih uporabnikov Sambe&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Remove the selected Samba user</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="176"/>
        <source>Add a Samba user (must match an existing Linux user)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="186"/>
        <source>Change the selected user&apos;s Samba password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>&amp;Password</source>
        <translation>&amp;Geslo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="225"/>
        <source>Users</source>
        <translation>Uporabniki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="250"/>
        <source>Enable or disable starting Samba automatically at boot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="253"/>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <location filename="../src/mainwindow.cpp" line="405"/>
        <source>E&amp;nable Automatic Samba Startup</source>
        <translation>&amp;Vklopi samodejni zagon Sambe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="260"/>
        <source>Start or stop the Samba service</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <location filename="../src/mainwindow.cpp" line="354"/>
        <location filename="../src/mainwindow.cpp" line="415"/>
        <source>Star&amp;t Samba</source>
        <translation>&amp;Zagon Sambe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="291"/>
        <source>Samba autostart service is disabled</source>
        <translation>Storitev za samodejni zagon Sambe je izklopljena</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <location filename="../src/mainwindow.cpp" line="355"/>
        <source>Samba is running</source>
        <translation>Samba se izvaja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="361"/>
        <source>About this application</source>
        <translation>O tem programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="364"/>
        <source>A&amp;bout...</source>
        <translation>O pro&amp;gramu...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="370"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Display help </source>
        <translation>Prikaži pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="405"/>
        <source>&amp;Help</source>
        <translation>Pomo&amp;č</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Quit application</source>
        <translation>Zapri aplikacijo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="449"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="455"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="118"/>
        <location filename="../src/mainwindow.cpp" line="123"/>
        <location filename="../src/mainwindow.cpp" line="130"/>
        <location filename="../src/mainwindow.cpp" line="144"/>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <location filename="../src/mainwindow.cpp" line="338"/>
        <location filename="../src/mainwindow.cpp" line="349"/>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <location filename="../src/mainwindow.cpp" line="534"/>
        <location filename="../src/mainwindow.cpp" line="568"/>
        <location filename="../src/mainwindow.cpp" line="572"/>
        <location filename="../src/mainwindow.cpp" line="578"/>
        <location filename="../src/mainwindow.cpp" line="585"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <location filename="../src/mainwindow.cpp" line="628"/>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="118"/>
        <source>Error, could not add share. Empty share name</source>
        <translation>Napaka - skupne rabe ni bilo mogoče dodati. Prazno ime skupne rabe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="115"/>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="123"/>
        <source>Path: %1 does not exist.</source>
        <translation>Pot: %1 ne obstaja.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="130"/>
        <source>Please set access for at least one user.</source>
        <translation>Določite dostop za vsaj enega uporabnika.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="145"/>
        <source>Could not add share. Error message:

%1</source>
        <translation>Skupne rabe ni bilo mogoče dodati: Sporočilo napake: 

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <source>Error listing users</source>
        <translation>Napaka pri izpisovanju uporabnikov</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="60"/>
        <source>&amp;Deny</source>
        <translation>&amp;Zavrni</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="61"/>
        <source>&amp;Read Only</source>
        <translation>%Samo &amp;branje</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="62"/>
        <source>&amp;Full Access</source>
        <translation>&amp;Poln dostop</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <source>Error listing shares</source>
        <translation>Napaka pri izpisovanju map v skupni rabi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="312"/>
        <source>Each Samba user can also open their own home folder, read-only, as \\%1\&lt;user name&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="313"/>
        <source>Each Samba user can also open their own home folder, with write access, as \\%1\&lt;user name&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="315"/>
        <source>This is set by the [homes] section in /etc/samba/smb.conf.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="339"/>
        <source>Your user doesn&apos;t belong to &apos;sambashare&apos; group  if you just installed the app you might need to restart the system first.</source>
        <translation>Vaš uporabnik ne spada v skupino &apos;sambashare&apos;. Če ste aplikacijo šele namestili je morda potreben ponovni zagon sistema.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="349"/>
        <source>Samba is not installed</source>
        <translation>Samba ni nameščena</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="354"/>
        <source>Sto&amp;p Samba</source>
        <translation>&amp;Zaustavi Sambo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="355"/>
        <source>Samba is not running</source>
        <translation>Samba ni zagnana</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="356"/>
        <source>Samba autostart is enabled</source>
        <translation>Samodejni zagon same je vklopljen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="356"/>
        <source>Samba autostart is disabled</source>
        <translation>Samodejni zagon same je izklopljen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="357"/>
        <source>&amp;Disable Automatic Samba Startup</source>
        <translation>&amp;Izklopi samodejni zagon Sambe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>MX Samba Config</source>
        <translation>MX Samba nastavitve</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="432"/>
        <source>Version: </source>
        <translation>Različica:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="434"/>
        <source>Program for configuring Samba shares and users.</source>
        <translation>Program za nastavljanje map v skupni rabi in uporabnikov s Sambo  </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Avtorska zaščita (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="437"/>
        <source>%1 License</source>
        <translation>%1 licenca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="443"/>
        <source>%1 Help</source>
        <translation>%1 pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="495"/>
        <source>%1 is listed on these shares:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="497"/>
        <source>Remove %1&apos;s access from: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="500"/>
        <source>Remove these shares, which no one else can access: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>Remove User</source>
        <translation>Odstrani uporabnika</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="503"/>
        <source>Remove from Shares</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="504"/>
        <source>Keep Entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <source>Cannot delete user: </source>
        <translation>Ne morem izbrisati uporabnika:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <source>%1 was removed, but these shares could not be updated: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="545"/>
        <source>Enter the username and password:</source>
        <translation>Vnesite uporabniško ime in geslo:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="552"/>
        <source>Username:</source>
        <translation>Uporabniško ime:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="553"/>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <source>Password:</source>
        <translation>&quot;Geslo:&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="554"/>
        <location filename="../src/mainwindow.cpp" line="610"/>
        <source>Confirm password:</source>
        <translation>Potrdite geslo:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="568"/>
        <source>Empty username, please enter a name.</source>
        <translation>Prazno ime - prosimo vnesite ime.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="573"/>
        <source>Matching linux user not found on system, make sure you enter a valid username.</source>
        <translation>Na sistemu ni bilo mogoče najti ustreznega Linux uporabnika. Uporabite ime, ki obstaja,</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="578"/>
        <location filename="../src/mainwindow.cpp" line="628"/>
        <source>Passwords don&apos;t match, please enter again.</source>
        <translation>Gesli se ne ujemata. Poskusite znova.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="585"/>
        <source>Could not add user.</source>
        <translation>Uporabnika ni bilo mogoče dodati.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="596"/>
        <location filename="../src/mainwindow.cpp" line="646"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <location filename="../src/mainwindow.cpp" line="672"/>
        <source>Warning</source>
        <translation>Opozorilo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="596"/>
        <source>No user selected.</source>
        <translation>Noben uporabnik ni izbran.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="603"/>
        <source>Change the password for &apos;%1&apos;</source>
        <translation>Spremeni geslo za &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <source>Password fields cannot be empty.</source>
        <translation>Polja za geslo ne smejo biti prazna.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>Could not change password.</source>
        <translation>Gesla ni bilo mogoče spremeniti.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="646"/>
        <location filename="../src/mainwindow.cpp" line="672"/>
        <source>No share selected.</source>
        <translation>Ni izbrane skupne rabe.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Selected share is empty.</source>
        <translation>Izbrana skupna raba je prazna.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <source>Cannot delete share: </source>
        <translation>Ne morem izbrisati skupne rabe:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <source>Success</source>
        <translation>Uspešno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <source>Share deleted successfully: </source>
        <translation>Skupna raba je bila izbrisana:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <location filename="../src/mainwindow.cpp" line="766"/>
        <source>Samba service is not running. Please start Samba before adding or editing shares</source>
        <translation>Storitev Samba se ne izvaja. Zaženite Sambo pred dodajanjem ali urejanjem skupne rabe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="683"/>
        <source>Edit Share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="689"/>
        <source>Share names cannot be changed when editing an existing share.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <source>Error processing permissions: </source>
        <translation>Napaka pri obdelavi dovolenj:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="755"/>
        <source>Several existing rules refer to this name; edit them individually.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Please add a Samba user before creating a share.</source>
        <translation>Izberite Samba uporabnika preden ustvarite skupno rabo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <source>Add Share</source>
        <translation>Dodaj skupno rabo</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Dnevnik sprememb</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="47"/>
        <location filename="../src/about.cpp" line="117"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <source>You must run this program as normal user.</source>
        <translation>Ta program morate zagnati kor navaden uporabnik.</translation>
    </message>
</context>
</TS>