inline const QString VERSION {"26.10"};
