<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sq">
<context>
    <name>EditShare</name>
    <message>
        <location filename="../src/editshare.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="20"/>
        <source>&amp;Name</source>
        <translation>&amp;Emër</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="30"/>
        <source>Browse for a folder to share</source>
        <translation>Shfletoni për një dosje për ndarje</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="33"/>
        <source>...</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="40"/>
        <source>&amp;Path</source>
        <translation>&amp;Shteg</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="50"/>
        <source>Full path to the folder to share</source>
        <translation>Shteg i plotë për te dosja për ndarje</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="57"/>
        <source>Allow access without a username or password</source>
        <translation>Lejo hyrje pa emër përdoruesi apo fjalëkalim</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="61"/>
        <source>Yes</source>
        <translation>Po</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="66"/>
        <source>No</source>
        <translation>Jo</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="74"/>
        <source>&amp;Comment</source>
        <translation>&amp;Koment</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="84"/>
        <source>Name clients will see for this share</source>
        <translation>Jepni emra klientësh që do të shohin për këtë pjesë</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="91"/>
        <source>&amp;Guest OK</source>
        <translation>Mysa&amp;firë OK</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="101"/>
        <source>Optional description shown to clients</source>
        <translation>Përshkrim opsional shfaqur klientëve</translation>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="111"/>
        <source>Changes apply to new connections. Clients that are already connected keep their current access until they reconnect. Restart Samba to apply the change to everyone immediately.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.ui" line="142"/>
        <source>Access rights for valid users</source>
        <translation>Të drejta hyrjeje për përdorues të vlefshëm</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="78"/>
        <source>Remove</source>
        <translation>Hiqe</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="80"/>
        <source>Remove this access rule</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="133"/>
        <source>Select directory to share</source>
        <translation>Përzgjidhni drejtori për ndarje</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="142"/>
        <source>Warning</source>
        <translation>Kujdes</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="142"/>
        <source>Select access for at least one user before continuing.</source>
        <translation>Para se të vazhdohet, përzgjidhni hyrje për të paktën një përdorues.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="24"/>
        <source>&amp;Shares</source>
        <translation>&amp;Pjesë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <source>Shares</source>
        <translation>Pjesë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba user shares found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;S’u gjetën pjesë përdoruesi samba&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="50"/>
        <source>Remove the selected share</source>
        <translation>Hiqe pjesën e përzgjedhur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="53"/>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Remove</source>
        <translation>&amp;Hiqe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="60"/>
        <source>Create a new Samba share</source>
        <translation>Krijoni një pjesë të re Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="69"/>
        <location filename="../src/mainwindow.ui" line="179"/>
        <source>&amp;Add</source>
        <translation>&amp;Shto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>Edit the selected share</source>
        <translation>Përpunoni pjesën e përzgjedhur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>&amp;Edit</source>
        <translation>&amp;Përpunoni</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="89"/>
        <source>Name</source>
        <translation>Emër</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="94"/>
        <source>Path</source>
        <translation>Shteg</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="99"/>
        <source>Comment</source>
        <translation>Koment</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Permissions</source>
        <translation>Leje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="109"/>
        <source>Guest OK</source>
        <translation>Mysafirë OK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="151"/>
        <source>&amp;Users</source>
        <translation>&amp;Përdorues</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;No samba users found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;S’u gjetën pjesë përdoruesi samba&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Remove the selected Samba user</source>
        <translation>Hiq përdoruesin Samba të përzgjedhur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="176"/>
        <source>Add a Samba user (must match an existing Linux user)</source>
        <translation>Shtoni një përdorues Samba (duhet të përputhet me një përdorues Linux ekzistues)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="186"/>
        <source>Change the selected user&apos;s Samba password</source>
        <translation>Ndryshoni fjalëkalimin e përdoruesit Samba të përzgjedhur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>&amp;Password</source>
        <translation>&amp;Fjalëkalim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="225"/>
        <source>Users</source>
        <translation>Përdorues</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="250"/>
        <source>Enable or disable starting Samba automatically at boot</source>
        <translation>Aktivizoni, ose çaktivizoni nisjen e automatizuar të Samba-s gjatë nisjes së sistemit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="253"/>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <location filename="../src/mainwindow.cpp" line="405"/>
        <source>E&amp;nable Automatic Samba Startup</source>
        <translation>&amp;Aktivizo Nisje të Vetvetishme të Samba-s</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="260"/>
        <source>Start or stop the Samba service</source>
        <translation>Nisni, ose ndalini shërbimin Samba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <location filename="../src/mainwindow.cpp" line="354"/>
        <location filename="../src/mainwindow.cpp" line="415"/>
        <source>Star&amp;t Samba</source>
        <translation>&amp;Nis Samba-n</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="291"/>
        <source>Samba autostart service is disabled</source>
        <translation>Shërbimi i vetënisjes së Samba-s është i çaktivizuar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <location filename="../src/mainwindow.cpp" line="355"/>
        <source>Samba is running</source>
        <translation>Samba po xhiron</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="361"/>
        <source>About this application</source>
        <translation>Mbi këtë aplikacion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="364"/>
        <source>A&amp;bout...</source>
        <translation>&amp;Mbi…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="370"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Display help </source>
        <translation>Shfaq ndihmën </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="405"/>
        <source>&amp;Help</source>
        <translation>&amp;Ndihmë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Alt+H</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Quit application</source>
        <translation>Mbylle aplikacionin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="449"/>
        <source>&amp;Close</source>
        <translation>&amp;Mbylle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="455"/>
        <source>Alt+N</source>
        <translation>Alt+M</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="118"/>
        <location filename="../src/mainwindow.cpp" line="123"/>
        <location filename="../src/mainwindow.cpp" line="130"/>
        <location filename="../src/mainwindow.cpp" line="144"/>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <location filename="../src/mainwindow.cpp" line="338"/>
        <location filename="../src/mainwindow.cpp" line="349"/>
        <location filename="../src/mainwindow.cpp" line="516"/>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <location filename="../src/mainwindow.cpp" line="569"/>
        <location filename="../src/mainwindow.cpp" line="578"/>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <location filename="../src/mainwindow.cpp" line="588"/>
        <location filename="../src/mainwindow.cpp" line="595"/>
        <location filename="../src/mainwindow.cpp" line="633"/>
        <location filename="../src/mainwindow.cpp" line="638"/>
        <location filename="../src/mainwindow.cpp" line="646"/>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="688"/>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <location filename="../src/mainwindow.cpp" line="734"/>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="118"/>
        <source>Error, could not add share. Empty share name</source>
        <translation>Gabim, s’u shtua dot pjesë. Emër i zbrazët pjese</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="115"/>
        <source>Yes</source>
        <translation>Po</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="123"/>
        <source>Path: %1 does not exist.</source>
        <translation>Shtegu %1 s’ekziston.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="130"/>
        <source>Please set access for at least one user.</source>
        <translation>Ju lutemi, ujdisni hyrje për të paktën një përdorues.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="145"/>
        <source>Could not add share. Error message:

%1</source>
        <translation>S’u shtua dot pjesë. Mesazh gabimi:

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <source>Error listing users</source>
        <translation>Gabim në shfaqje përdoruesish</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="60"/>
        <source>&amp;Deny</source>
        <translation>&amp;Hidhe poshtë</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="61"/>
        <source>&amp;Read Only</source>
        <translation>Vetëm &amp;Lexim</translation>
    </message>
    <message>
        <location filename="../src/editshare.cpp" line="62"/>
        <source>&amp;Full Access</source>
        <translation>Hyrje e &amp;Plotë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <source>Error listing shares</source>
        <translation>Gabim në shfaqje pjesësh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="312"/>
        <source>Each Samba user can also open their own home folder, read-only, as \\%1\&lt;user name&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="313"/>
        <source>Each Samba user can also open their own home folder, with write access, as \\%1\&lt;user name&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="315"/>
        <source>This is set by the [homes] section in /etc/samba/smb.conf.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="339"/>
        <source>Your user doesn&apos;t belong to &apos;sambashare&apos; group  if you just installed the app you might need to restart the system first.</source>
        <translation>Përdoruesi juaj s’i përket grupit “sambashare”  nëse sapo e instaluar aplikacionin, mund të doni të rinisni sistemin, së pari.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="349"/>
        <source>Samba is not installed</source>
        <translation>Samba s’është e instaluar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="354"/>
        <source>Sto&amp;p Samba</source>
        <translation>N&amp;dale Samba-n</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="355"/>
        <source>Samba is not running</source>
        <translation>Samba s’është në punë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="356"/>
        <source>Samba autostart is enabled</source>
        <translation>Vetënisja e Samba-s është e aktivizuar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="356"/>
        <source>Samba autostart is disabled</source>
        <translation>Vetënisja e Samba-s është e çaktivizuar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="357"/>
        <source>&amp;Disable Automatic Samba Startup</source>
        <translation>&amp;Çaktivizo Nisje të Vetvetishme të Samba-s</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>About %1</source>
        <translation>Mbi %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>MX Samba Config</source>
        <translation>Formësim MX i Samba-s</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="432"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="434"/>
        <source>Program for configuring Samba shares and users.</source>
        <translation>Program për formësim pjesësh dhe përdoruesish Samba.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Të drejta kopjimi (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="437"/>
        <source>%1 License</source>
        <translation>Licencë %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="443"/>
        <source>%1 Help</source>
        <translation>Ndihmë për %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="496"/>
        <source>%1 is listed on these shares:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="498"/>
        <source>Remove %1&apos;s access from: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="501"/>
        <source>Remove these shares, which no one else can access: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="503"/>
        <source>Remove User</source>
        <translation>Hiqeni Përdoruesin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="504"/>
        <source>Remove from Shares</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="505"/>
        <source>Keep Entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="516"/>
        <source>Cannot delete user: </source>
        <translation>S’fshihet dot përdoruesi: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>%1 was removed, but these shares could not be updated: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="546"/>
        <source>Enter the username and password:</source>
        <translation>Jepni emër përdoruesi dhe fjalëkalim:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="553"/>
        <source>Username:</source>
        <translation>Emër përdoruesi:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="554"/>
        <location filename="../src/mainwindow.cpp" line="619"/>
        <source>Password:</source>
        <translation>Fjalëkalim:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="555"/>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <source>Confirm password:</source>
        <translation>Ripohoni fjalëkalimin:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="569"/>
        <source>Empty username, please enter a name.</source>
        <translation>Emër i zbrazët përdoruesi, ju lutemi, jepni një emër.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="579"/>
        <source>Matching linux user not found on system, make sure you enter a valid username.</source>
        <translation>Në sistem s’u gjet përdorues linux me përputhje, sigurohuni se dhatë një emër të vlefshëm përdoruesi.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="588"/>
        <location filename="../src/mainwindow.cpp" line="638"/>
        <source>Passwords don&apos;t match, please enter again.</source>
        <translation>Fjalëkalimet nuk përputhen, ju lutemi, rijepini.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="595"/>
        <source>Could not add user.</source>
        <translation>S’u shtua dot përdorues.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="606"/>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <location filename="../src/mainwindow.cpp" line="663"/>
        <location filename="../src/mainwindow.cpp" line="683"/>
        <source>Warning</source>
        <translation>Kujdes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="606"/>
        <source>No user selected.</source>
        <translation>S’u përzgjodh përdorues.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="613"/>
        <source>Change the password for &apos;%1&apos;</source>
        <translation>Ndryshoni fjalëkalimin për &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <location filename="../src/mainwindow.cpp" line="633"/>
        <source>Password fields cannot be empty.</source>
        <translation>Fushat e fjalëkalimit s’mund të jenë të zbrazëta.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="646"/>
        <source>Could not change password.</source>
        <translation>S’u ndryshua dot fjalëkalim.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <location filename="../src/mainwindow.cpp" line="683"/>
        <source>No share selected.</source>
        <translation>S’u përzgjodh pjesë.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="663"/>
        <source>Selected share is empty.</source>
        <translation>Pjesa e përzgjedhur është e zbrazët.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <source>Cannot delete share: </source>
        <translation>S’fshihet dot pjesë: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="649"/>
        <location filename="../src/mainwindow.cpp" line="673"/>
        <source>Success</source>
        <translation>Sukses</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="649"/>
        <source>Password changed successfully for &apos;%1&apos;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="673"/>
        <source>Share deleted successfully: </source>
        <translation>Pjesa u fshi me sukses:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="689"/>
        <location filename="../src/mainwindow.cpp" line="777"/>
        <source>Samba service is not running. Please start Samba before adding or editing shares</source>
        <translation>Shërbimi samba s’është në punë. Ju lutemi, nisni Samba-n para se të shtoni ose të përpunoni pjesë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="694"/>
        <source>Edit Share</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Share names cannot be changed when editing an existing share.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <location filename="../src/mainwindow.cpp" line="734"/>
        <source>Error processing permissions: </source>
        <translation>Gabim në përpunim lejesh:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="766"/>
        <source>Several existing rules refer to this name; edit them individually.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <source>Please add a Samba user before creating a share.</source>
        <translation>Ju lutemi, shtoni një përdorues Samba, para krijimit të një pjese.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>Add Share</source>
        <translation>Shtoni Pjesë</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>Could not load %1</source>
        <translation>S’u ngarkua dot %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licencë</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Regjistër ndryshimesh</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Anuloje</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="47"/>
        <location filename="../src/about.cpp" line="117"/>
        <source>&amp;Close</source>
        <translation>&amp;Mbylle</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <source>You must run this program as normal user.</source>
        <translation>Këtë program duhet ta xhironi si përdorues i thjeshtë.</translation>
    </message>
</context>
</TS>